﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'smiley', 'ja', {
	options: '絵文字オプション',
	title: '顔文字挿入',
	toolbar: '絵文字'
} );
