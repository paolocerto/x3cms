﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'smiley', 'ko', {
	options: '이모티콘 옵션',
	title: '아이콘 삽입',
	toolbar: '아이콘'
} );
