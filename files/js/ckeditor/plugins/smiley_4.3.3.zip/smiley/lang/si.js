﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'smiley', 'si', {
	options: 'හාස්‍ය විකල්ප',
	title: 'හාස්‍යන් ඇතුලත් කිරීම',
	toolbar: 'හාස්‍යන්'
} );
